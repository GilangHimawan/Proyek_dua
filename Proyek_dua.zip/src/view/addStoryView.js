import { setupMapForLatLon } from '../utils/locationMap.js';
import { startCamera, triggerFileInput, capturePhoto } from '../utils/cameraUtils.js';

export function renderAddStoryForm() {
  const root = document.getElementById('main-content');
  root.innerHTML = `
    <h2>Tambah Cerita</h2>
    <form id="story-form">
      <label>Deskripsi:</label>
      <textarea id="story-description" required></textarea>

      <label>Foto:</label>
      <button type="button" id="choose-photo">Pilih dari Perangkat</button>
      <button type="button" id="open-camera">Ambil dari Kamera</button>

      <div id="camera-container" style="display:none;">
        <video id="video" width="320" height="240" autoplay></video>
        <button type="button" id="capture-btn">Ambil Foto</button>
        <canvas id="canvas" style="display:none;"></canvas>
      </div>

      <input type="file" id="story-photo" accept="image/*" style="display:none;" />
      <input type="hidden" id="story-photo-base64" />
      <input type="hidden" id="story-lat" />
      <input type="hidden" id="story-lon" />
      <div id="map" style="height:300px;margin-top:10px;"></div>

      <button type="submit">Kirim Cerita</button>
    </form>
  `;

  setupMapForLatLon();

  document.getElementById('choose-photo').addEventListener('click', triggerFileInput);
  document.getElementById('open-camera').addEventListener('click', startCamera);
  document.getElementById('capture-btn').addEventListener('click', capturePhoto);

  document.getElementById('story-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const storyData = {
      description: document.getElementById('story-description').value,
      photoFile: document.getElementById('story-photo').files[0],
      base64: document.getElementById('story-photo-base64').value,
      lat: document.getElementById('story-lat').value,
      lon: document.getElementById('story-lon').value,
    };

    console.log(storyData);
  });
}
