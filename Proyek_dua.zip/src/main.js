import { initRouter } from './routes/router.js';
import './tampilan.css';


document.addEventListener('DOMContentLoaded', () => {
  initRouter(); 
});
