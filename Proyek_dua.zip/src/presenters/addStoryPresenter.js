import { renderAddStoryForm } from '../view/addStoryView.js';
import { dataURLToBlob } from '../utils/dataURLToBlob.js';

export function addNewStory() {
  if (document.startViewTransition) {
    document.startViewTransition(() => renderAddStoryForm(handleSubmitStory));
  } else {
    renderAddStoryForm(handleSubmitStory);
  }
}

async function handleSubmitStory({ description, photoFile, base64, lat, lon }) {
  const token = localStorage.getItem('token');
  if (!token) {
    alert('Sesi habis, silakan login lagi.');
    location.hash = '#login';
    return;
  }

  const formData = new FormData();
  formData.append('description', description);

  if (photoFile) {
    formData.append('photo', photoFile);
  } else if (base64) {
    const blob = dataURLToBlob(base64);
    formData.append('photo', blob, 'camera-photo.png');
  } else {
    alert('Silakan pilih atau ambil foto.');
    return;
  }

  if (lat && lon) {
    formData.append('lat', lat);
    formData.append('lon', lon);
  }

  try {
    const res = await fetch('https://story-api.dicoding.dev/v1/stories', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: formData,
    });

    const data = await res.json();
    if (!data.error) {
      alert('Cerita berhasil dikirim!');
      location.hash = '#home';
    } else {
      alert(data.message || 'Gagal mengirim!');
    }
  } catch (err) {
    alert('Error: ' + err.message);
  }
}
